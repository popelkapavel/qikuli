Qikuli - break all blocks with minimum moves

Left and right shift blocks, or jump on block.
Up go through the block, down destroy block.

http://popelkapavel.sweb.cz/qikuli/qikuli.htm

Keys 
  
  PgUp,Enter - next/reset level
  PgDown,Backspace - previous/reset level
  numpad digits - level number
  F11,Alt+Enter,Control+Enter - switch fullscreen
  Ctrl+Z,Z,Delete - undo
  Ctrl+Y,Y,Insert - redo

  Cursor keys - move
  Shift,Ctrl,Alt - jump (+ left or right)

  X,F4 - mirror x

mouse
  left button - move to cursor
  double click ball  - switch fullscreen

command line
  qikuli.exe [levels_file.txt]   